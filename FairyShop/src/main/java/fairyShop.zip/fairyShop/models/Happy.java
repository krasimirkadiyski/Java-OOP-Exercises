package fairyShop.models;

public class Happy extends BaseHelper{
    private static final int ENERGY_OF_HAPPY_ELF = 100;

    public Happy(String name) {
        super(name, ENERGY_OF_HAPPY_ELF);
    }
}
