package catHouse.entities.toys;

public class Mouse extends BaseToy{
    private static final int SOFTNESS_OF_THE_MOUSE = 5;
    private static final int PRICE_OF_THE_MOUSE = 15;


    public Mouse() {
        super(SOFTNESS_OF_THE_MOUSE, PRICE_OF_THE_MOUSE);
    }
}
