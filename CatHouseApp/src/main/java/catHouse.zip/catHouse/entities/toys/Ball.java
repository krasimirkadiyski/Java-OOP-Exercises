package catHouse.entities.toys;

public class Ball extends BaseToy{
    private static final int SOFTNESS_OF_THE_BALL = 1;
    private static final int PRICE_OF_THE_BALL = 10;
    public Ball() {
        super(SOFTNESS_OF_THE_BALL, PRICE_OF_THE_BALL);
    }
}
